const { initService } = require('./src/business')

initService()